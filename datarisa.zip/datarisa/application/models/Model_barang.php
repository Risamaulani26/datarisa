<?php
class model_barang extends CI_model
{
    public function getAllBarang()
    {
        return $query = $this->db->get('barang')->result_array();
    }

    public function Tambahbarang()
    {
        $data = [
            "barang" => $this->input->post('barang', true)
        ];

        $this->db->insert('barang', $data);
    }

    public function Ubahbarang()
    {
        $data = [
            "barang" => $this->input->post('barang', true)
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('barang', $data);
    }

    public function hapusbarang($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('barang');
    }

    public function getBarangById($id)
    {
        return $query = $this->db->get_where('barang', ['id' => $id])->row_array();
    }

    public function Caribarang()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('barang', $keyword);
        return $this->db->get('barang')->result_array();
    }
}

?>