<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengiriman extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('Model_pengiriman');
        $this->load->model('Model_barang');
        if(!$this->session->userdata('username')) {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] ='pengiriman';
        if ($this->input->post('submit')) {
            $data['keyword'] = $this->input->post('keyword');
        } else {
            $data['keyword'] = null;
        }

        $data['pengiriman'] = $this->Model_pengiriman->getAllPengiriman($data['keyword']);

        $this->load->view('templates/header.php', $data);
        $this->load->view('pengiriman/index.php', $data);
        $this->load->view('templates/footer.php');
    }

    public function tambah()
    {
        $data['pengiriman'] = $this->Model_pengiriman->getAllPengiriman();
        $this->form_validation->set_rules('nama_barang', 'Nama_barang', 'trim|required');
        $this->form_validation->set_rules('tanggal_masuk', 'Tanggal_masuk', 'trim|required|date');
        $this->form_validation->set_rules('alamat', 'Alamat', 'trim|required');
        $this->form_validation->set_rules('keterangan', 'Keterangan', 'trim|required');
        $this->form_validation->set_rules('nama_pengantar', 'Nama_pengantar', 'trim|required');

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Tambah pengiriman';

            $this->load->view('templates/header.php', $data);
            $this->load->view('pengiriman/tambah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_pengiriman->Tambahpengiriman();
            redirect('pengiriman');
        }
    }

    public function ubah($id)
    {
        $data['pengiriman'] = $this->Model_pengiriman->getPengirimanById($id);
        $this->form_validation->set_rules('nama_barang', 'Nama_barang', 'trim|required');
        $this->form_validation->set_rules('tanggal_masuk', 'Tanggal_masuk', 'trim|required|date');
        $this->form_validation->set_rules('alamat', 'Alamat', 'trim|required');
        $this->form_validation->set_rules('keterangan', 'Keterangan', 'trim|required');
        $this->form_validation->set_rules('nama_pengantar', 'Nama_pengantar', 'trim|required');


        if($this->form_validation->run() == false ) {
            $data['title'] = 'ubah Pengiriman';

            $this->load->view('templates/header.php', $data);
            $this->load->view('pengiriman/ubah.php', $data);
            $this->load->view('templates/footer.php', $data);
        }else {
            $this->Model_pengiriman->Ubahpengiriman();
            $old_image = $data['siswa']['foto'];
            unlink(FCPATH . 'assets/foto/' . $old_image);
            $this->session->set_flashdata('flash', 'Diubahkan');
            redirect('pengiriman');
        }

    }

    public function detail($id)
    {
        $data['pengiriman'] = $this->Model_pengiriman->getPengirimanById($id);

        $data['title'] = 'Detail Pengiriman';
        $this->load->view('templates/header.php', $data);
        $this->load->view('pengiriman/detail.php', $data);
        $this->load->view('templates/footer.php', $data);
    
    }

    public function hapus($id)
    {
        $data['pengiriman'] = $this->Model_pengiriman->getPengirimanById($id);
        $old_image = $data['pengiriman']['foto'];
        unlink(FCPATH . 'assets/foto/' . $old_image);
        $this->Model_pengiriman->hapusPengiriman($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('pengiriman');

    }
}
