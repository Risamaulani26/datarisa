<?php
defined('BASEPATH') OR exit('No direct script acces allowed');

class barang extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('Model_barang');
        if(!$this->session->userdata('username')) {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] ='barang';

        $data['barang'] = $this->Model_barang->getAllBarang();
        if( $this->input->post('keyword') ) {
            $data['barang'] = $this->Model_barang->Caribarang();
        }
        $this->load->view('templates/header.php', $data);
        $this->load->view('barang/index.php', $data);
        $this->load->view('templates/footer.php');
    }

    public function tambah()
    {
        $this->form_validation->set_rules('barang', 'barang', 'trim|required');

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Tambah barang';

            $this->load->view('templates/header.php', $data);
            $this->load->view('barang/tambah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_barang->tambahbarang();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('barang');
        }
   
    }
    
    public function ubah($id)
    {
        $this->form_validation->set_rules('barang', 'barang', 'trim|required');
        $data['barang'] = $this->Model_barang->getbarangById($id);

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Ubah Barang';

            $this->load->view('templates/header.php', $data);
            $this->load->view('barang/ubah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_barang->Ubahbarang();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('barang');
        }

    }
  
    public function hapus($id)
    {
        $this->Model_barang->hapusBarang($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('barang');
    }
}