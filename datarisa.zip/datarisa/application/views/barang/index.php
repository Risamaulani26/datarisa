<div class="container">
<legend>Data Barang</legend>
<a class="btn btn-primary" href="<?= base_url('barang/tambah'); ?>" role="button">Tambah Barang</a>
<?php if( $this->session->flashdata('flash') ) : ?>
    <div class="alert alert-succes alert-dismissible fade show mt-2 mb-2" role="alert">
        Data barang <strong>berhasil</strong> <?= $this->session->flashdata('flash'); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
    </div>
<?php endif; ?>
    <form action="" method="post" class="d-flex mb-2 mt-2" role="search">
        <input class="form-control me-2" type="text" placeholder="cari" aria-label="search" name="keywod" style="width : 500px">
        <button class="btn btn-outline-success" type="submit">Cari</button>
    </form>
    <table class="table">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Nama</th>
            <th scope="col">action</th>
            </tr>
        </thead>
        <tbody>
            <?php if( empty($barang) ) : ?>
                <tr>
                    <td colspan=2>
                        <div class="alert alert-danger" role="alert">
                            Data Barang Tidak Ditemukan
                        </div>
                    </td>
                </tr>
            <?php endif; ?>
            <?php $i=1; ?>
            <?php foreach( $barang as $bar ) : ?>
                <tr>
                    <th scope="row"><?= $i++; ?></th>
                    <td><?= $bar['barang']; ?></td>
                    <td>
                        <a href="<?=base_url('barang/ubah/'); ?><?= $bar['id']; ?>" class="badge text-bg-warning">Ubah</a>
                        <a href="<?=base_url('barang/hapus/'); ?><?= $bar['id']; ?>" class="badge text-bg-danger" onclick="return confirm('yakin');">Hapus</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<style>
    body {
        background: #FFE4C4;
    }
</style>