<div class="container">
    <div class="card" style="width: 18rem;">
    <img src="<?= base_url('assets/foto/') . $pengiriman['foto']; ?>" class="card-img-top" alt="...">
        <div class="card-body">
        <li class="list-group-item"><?= $pengiriman['tanggal_masuk']; ?></li>
        <li class="list-group-item"><?= $pengiriman['nama_barang']; ?></li>
        </div>
        <ul class="list-group list-group-flush">
            <li class="list-group-item"><?= $pengiriman['alamat']; ?></li>
            <li class="list-group-item"><?= $pengiriman['keterangan']; ?></li>
            <li class="list-group-item"><?= $pengiriman['nama_pengantar']; ?></li>
        </ul>
        <div class="card-body">
            <a href="<?= base_url('pengiriman'); ?>" class="btn btn-primary">kembali</a>
        </div>
    </div>
</div>